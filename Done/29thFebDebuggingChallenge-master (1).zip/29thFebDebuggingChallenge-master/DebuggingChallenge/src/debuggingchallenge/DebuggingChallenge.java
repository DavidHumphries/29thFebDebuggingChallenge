package debuggingchallenge;

/**
 *
 * @author rhodso
 */
public class DebuggingChallenge {
    
    public static void main(String[] args) {
        //Create a GUI instance, then set it to visible when it's done in the constructor
        GUI g = new GUI();
        g.setVisible(true);
        
    }
}
