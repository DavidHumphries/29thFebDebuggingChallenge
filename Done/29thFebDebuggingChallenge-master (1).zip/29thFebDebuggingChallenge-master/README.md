# 29thFebDebuggingChallenge

Welcome to the repository for the debugging challenge!

1) Fork this repository
2) Read the specification of how the program is supposed to work (spec.txt)
3) Make the program work
4) Submit a link to your version of the program on the Google form

That's it
